s = 15;

if (s <= 10){
	console.log(“The value of s is less than or equal to 10”);
} else{
	console.log(“The value of s is greater than 10”);
}